setTimeout(function() {
    alert("Hey le site xxxvidsxxx est trop bien. Viens dessus stp please");
},2000);
